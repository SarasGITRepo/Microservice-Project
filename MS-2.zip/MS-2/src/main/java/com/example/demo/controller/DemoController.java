package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.User;
import com.example.demo.service.DemoService;

@RestController
public class DemoController {
	
	@Autowired
	DemoService service;
	
	
	@GetMapping(value = "/getUser")
	public List<User> listUser(){
		return service.getUserList();
	}


	@PostMapping(value = "/send")
	public void getObject(){
			service.sendObject();
		 
	}
	
}
