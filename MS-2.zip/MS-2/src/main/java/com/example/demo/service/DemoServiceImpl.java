package com.example.demo.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.dto.Employee;
import com.example.demo.dto.User;

@Service
public class DemoServiceImpl implements DemoService {
	
	//@Autowired
	//private RestTemplate template;
	public static List<User> object ;
	RestTemplate template = new RestTemplate();
	
	
	@Override
	public List<User> getUserList() {
		ResponseEntity<User[]> entity = template.getForEntity("http://localhost:4444/user", User[].class);
		//List<UserDTO> object = Arrays.asList(entity.getBody());
		object = Arrays.asList(entity.getBody());
		System.out.println("object:::"+object);
		return object;
	}


	@Override
	public void sendObject() {
		
		//String message = "Hello";
	//	template.postForEntity("http://localhost:4444/receive", object, null);
		Employee employee = new Employee();
		employee.setCountry("India");
		employee.setLocation("Chennai");
		System.out.println("country::::::::::"+employee.getCountry());
		HttpEntity<Employee> entity = new HttpEntity<Employee>(employee);
		template.exchange("http://localhost:4444/receive", HttpMethod.POST, entity, Employee.class);
		
		
	}

	
/*@Override
	public ResponseEntity<UserDTO[]>  getObject(){
		   HttpHeaders headers = new HttpHeaders();
		    headers.setContentType(MediaType.APPLICATION_JSON);
		   // UserDTO data = new UserDTO();
		    String name = "Saras";
		    HttpEntity<?> entity = new HttpEntity<Object>(name,headers);
		 //   ResponseEntity<UserDTO[]> responseEntity =    template.exchange("http://localhost:4444/receive", HttpMethod.PUT, entity, UserDTO[].class);
		    ResponseEntity<UserDTO[]> responseEntity =    template.postForEntity("http://localhost:4444/receive", HttpMethod.POST,  UserDTO[].class, name);
		    
		    return responseEntity;
		
	}*/
}
