package com.example.demo.dto;

import org.springframework.beans.factory.annotation.Value;

public class Employee {
	
	String location;
	String country;

	public String getCountry() {
		return country;
	}
	
	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "Employee [location=" + location + ", country=" + country + "]";
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

}
