package com.example.demo.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.example.demo.dto.User;

public interface DemoService {
	
	public List<User> getUserList();
	
	//public  ResponseEntity<UserDTO[]> getObject();
	
	public void sendObject();

}
