INSERT INTO user (id, location, name)
VALUES (1, hyd, saras);