package com.user.data.service;

import java.util.List;

import com.user.data.entity.User;

public interface UserService {
	//public List<User> getUser();
	
	public void loadUser() ;
	public List<User> getUser();
	public String getMessage();

}
