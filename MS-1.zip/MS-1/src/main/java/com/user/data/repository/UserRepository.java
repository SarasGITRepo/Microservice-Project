package com.user.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.user.data.entity.User;

@Repository("repo")
public interface UserRepository  extends JpaRepository<User, Long>{

}
