package com.user.data.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.user.data.entity.User;
import com.user.data.model.Employee;
import com.user.data.service.UserService;
import com.user.data.service.UserServiceImpl;

@RestController
public class UserController {
	
	@Autowired
	UserService service;
	
/*	@GetMapping(value = "/user")
	public List<User> listUser(Model model){
		
		return service.loadUser();
	}
*/
	
	
	@GetMapping(value = "/user")
	public List<User> listUser(){
		return service. getUser();

	
	}
	/*@ResponseBody
	@PostMapping(value = "/receive" )
	public User receiveObject(@RequestBody User user){
		System.out.println("object receive"+user); 
		return user;

	
	}*/
	//@ResponseBody
	@PostMapping(value = "/receive" )
	public Employee receiveEmp( @RequestBody Employee employee){
		System.out.println("object receive post method:"+employee); 
		return employee;

	
	}
/*	@ResponseBody
	@GetMapping(value = "/receive" )
	public Employee receiveEmp1( Employee employee){
		System.out.println("object receive get method:"+employee); 
		return employee;

	
	}*/
}
