package com.user.data.service;

import java.util.List;
import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.user.data.entity.User;
import com.user.data.repository.UserRepository;


@Service
public class UserServiceImpl implements UserService{

		
	@Autowired 
	UserRepository userRepo;
	
	public static List<User> user;
	
	
/*	@Override
	public List<User> getUser() {
		// TODO Auto-generated method stub
		return userRepo.findAll();
	}
*/

	
	@PostConstruct
	public void init() {
		System.out.println("*****loaded during start up*****");
	}
	
	@PostConstruct
	@Override
	public void loadUser() {
		
		user= userRepo.findAll();
			
		
	/*for(User user : userRepo.findAll()) {
		
			System.out.println("Id: " + user.getId());
			System.out.println("Name: " + user.getName());
			System.out.println("Location: " + user.getLocation());
			System.out.println("User variable::"+user);
			
		}
		*/
		
	}
	
	@Override
	public List<User> getUser(){
		
		return user;
		
	}
	@Override
	public String getMessage() {
		
		return null ;
		
	}

	
}
