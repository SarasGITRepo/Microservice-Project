package com.user.data;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.user.data.entity.User;
import com.user.data.repository.UserRepository;

@SpringBootApplication
public class Ms1Application {
//implements CommandLineRunner
	
	@Autowired
	UserRepository repo;
	
	public static void main(String[] args) {
		SpringApplication.run(Ms1Application.class, args);
	}

		
	/*	public void run(String... arg0) throws Exception {
			for(User user : repo.findAll()) {
				System.out.println("Id: " + user.getId());
				System.out.println("Name: " + user.getName());
				System.out.println("Location: " + user.getLocation());
				
			}
		}
	*/
}
