package com.user.data.model;

import org.springframework.beans.factory.annotation.Value;

public class Employee {
	String location;
	String country;

	public String getCountry() {
		return country;
	}
	@Value(value = "india")
	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "Employee [location=" + location + ", country=" + country + "]";
	}

	public String getLocation() {
		return location;
	}
@Value(value = "HYD")
	public void setLocation(String location) {
		this.location = location;
	}
}
