package com.demo.hello;

public class User {
	
	String name;
	String city;

}
