package com.demo.hello.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.hello.User;
import com.demo.hello.repository.HelloRepository;

@Service
public class HelloService {
	
/*	@Autowired
	private HelloRepository repo;
	
	public String saveUser(User user) {
		return repo.save(user);
	}*/

}
