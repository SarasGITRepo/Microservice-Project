package com.demo.hello.repository;

import org.springframework.stereotype.Repository;

import com.demo.hello.User;

//@Repository
public interface HelloRepository   {

	String save(User user);
	
	
	
}
