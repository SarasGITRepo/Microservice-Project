package com.demo.hello;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	
	@GetMapping(value="/hello/{name}")
	public String sayHi(@PathVariable("name")String name) {
		String msg = "From Hello Service" +name ;
		return msg;
		
	}
	

	
	
/*	public User getUser(@RequestParam(value = "name") String name) {
		return getUser(name);
	}
	*/
}
