CREATE TABLE demo_ms (
    name varchar(256),
    age int(2))