package com.hitachi.energy.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;




import lombok.Data;
@Data
@Entity
//@Table(name = "User_Table")
@Table(name = "employee_table")
public class EmployeeEntity {
/*
 * create table employee_table (
       empid integer not null,
        age integer,
        department varchar(255),
        doj varchar(255),
        fname varchar(255),
        lname varchar(255),
        mname varchar(255),
        skills VARCHAR,
        primary key (empid)
    ) 	
 */
	@javax.persistence.Id
   // @GeneratedValue(strategy = GenerationType.IDENTITY)
	//private long ID;
	
	//@Column(name = "empID")
	private Integer empID;
	
	@Column(name = "FName")
	private String fname;
	
	  
	@Column(name = "MName")
	private String mname;
	
	@Column(name = "Lname")
	private String lname;
	
	@Column(name = "Age")
	private Integer age;
 
	//@Column(name = "EmployeeID")
	//private Long empID;
	
	@Column(name = "Department")
	private String department;
	
	@Column(name = "Skills", columnDefinition = "VARCHAR")
	private String skills;
	
	
	@Column(name = "DOJ")
	private String doj;
	
	
	
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Integer getEmpID() {
		return empID;
	}
	public void setEmpID(Integer empID) {
		this.empID = empID;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	/*public long getID() {
		return ID;
	}
	public void setID(long iD) {
		ID = iD;
	}
	
	*/
	


}
