package com.hitachi.energy.controller;

import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hitachi.energy.model.EmployeeDataModel;
import com.hitachi.energy.service.EmployeeDataService;

@RestController
//@RequestMapping("/save")
public class EmployeeRestController {
	
	
	@Autowired
	private EmployeeDataService empService;

/*	@GetMapping(value="/employeeRecord/{name}")
	public String employeeRecord(@PathVariable("name") String name) {
		
		String msg = "I am from Employee Record";
		return msg;
	}
*/
	/*@PostMapping(value= "/save")
	public EmployeeDataModel saveEmp(@RequestBody EmployeeDataModel empModel) {
		System.out.println("*****************"+empModel.getName()+"***************");
		System.out.println("*****************"+empModel.getAge()+"***************");
		System.out.println("*****************"+empModel.getEmpID()+"***************");
		System.out.println("*****************"+empModel.getDoj()+"***************");
		System.out.println("*****************"+empModel.getSkills()+"***************");
		empService.saveUser(empModel);
		return empModel;
		
	}
	*/
	
	
}
