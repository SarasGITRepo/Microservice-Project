package com.hitachi.energy.exception;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@Controller
@ControllerAdvice
public class EmployeeExceptions extends RuntimeException{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
/*public String exceptionHandler(Model model) {
		
		return "error";

	}
*/
@ExceptionHandler(value = NullPointerException.class)
	public String handleControllerBasedException(Model model) {
		model.addAttribute("errorMsg","Some problem occured");
	return "error";
		
	}

@ExceptionHandler(value = CustomException.class)
public String empIDNotFound(Model model) {
	model.addAttribute("errorMsg","Requested ID Doesn't exist");
return "error";
	
}

}
