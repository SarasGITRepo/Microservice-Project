package com.hitachi.energy.repository;

import java.io.Serializable;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hitachi.energy.entity.EmployeeEntity;

@Repository
public interface EmployeeRepository extends JpaRepository<EmployeeEntity, Serializable>{
	
	public List<EmployeeEntity> findAll();
	
	//EmployeeEntity findById(long id);
	
	@Query(name="from EmployeeEntity where Employee_ID = :empID")
	public EmployeeEntity  findByEmpID(Integer empID);
	//List<Product> findAllByPrice(double price, Pageable pageable);
//	Pageable firstPage = PageRequest.of(0, 10);
///	@Modifying
//	@Query("UPDATE  EmployeeEntity e  set e.doj = ?1 WHERE e.empID=:empID")
//	public EmployeeEntity  upDateByEmpID(@Param("empID") Integer empID);
	
	//@Query("update EmployeeEntity e set e.name = ?1, e.age = ?2 ,  e.department = ?4, e.skills = ?5, e.doj = ?6 where e.empID = ?3")
	//public int updateByEmpID(Long empID);
	
	//public  void deleteById(Integer empID);
	
/*	@Modifying
    @Query("UPDATE EmployeeEntity c SET c.fname = :fname,c SET c.fname = :fname,c SET c.mname = :mname,c SET c.lname = :lname,c SET c.age = :age,c SET c.department = :department,c SET c.skills = :skills, WHERE c.empID = :empID")
	Long updateByEmpID(@Param("empID") Long empID);
	*/
@Modifying  
  @Query(value = "DELETE FROM EmployeeEntity e WHERE e.empID = :empID") 
   	void deleteByEmpID( @Param("empID")Integer empID);
	
}
