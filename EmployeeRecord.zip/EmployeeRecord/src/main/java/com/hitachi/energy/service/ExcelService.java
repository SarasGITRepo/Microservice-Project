package com.hitachi.energy.service;

import java.io.ByteArrayInputStream;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hitachi.energy.entity.EmployeeEntity;
import com.hitachi.energy.exception.EmployeeExceptions;
import com.hitachi.energy.helper.EmployeeDataExcel;
import com.hitachi.energy.repository.EmployeeRepository;

@Service
public class ExcelService {

	
	@Autowired
	EmployeeRepository repository;
	  public ByteArrayInputStream load() throws EmployeeExceptions {
	    List<EmployeeEntity> Employee_Table = repository.findAll();
	    ByteArrayInputStream stream = EmployeeDataExcel.empDataToExcel(Employee_Table);
	    
	    return stream;
	  }
}
