package com.hitachi.energy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hitachi.energy.entity.EmployeeEntity;
import com.hitachi.energy.repository.EmployeeRepository;

@Service
public class PdfService {

	 @Autowired
	    private EmployeeRepository repo;
	     
	    public List<EmployeeEntity> listAll() {
	        return repo.findAll();
	    }
	     
}
