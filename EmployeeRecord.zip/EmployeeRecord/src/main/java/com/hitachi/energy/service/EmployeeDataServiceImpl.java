package com.hitachi.energy.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hitachi.energy.controller.EmployeeDataController;
import com.hitachi.energy.entity.EmployeeEntity;
import com.hitachi.energy.exception.CustomException;
import com.hitachi.energy.model.EmployeeDataModel;
import com.hitachi.energy.repository.EmployeeRepository;

@Service
@Transactional

public class EmployeeDataServiceImpl implements EmployeeDataService {
	@Autowired
	private EmployeeRepository empRepo;
	private static final Logger logger = LoggerFactory.getLogger(EmployeeDataController.class);
	@Override
	public boolean saveUser(EmployeeDataModel emodel) {
		EmployeeEntity eEntity = new EmployeeEntity();
		//Date today =	 emodel.getDoj();
		// DateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
		
		BeanUtils.copyProperties(emodel, eEntity);
		
		try{
			empRepo.save(eEntity);
		}
		catch(Exception e) {
			throw new CustomException("Unable to Save The Deatils ");
			
		}
		System.out.println("service class entity::"+eEntity.getSkills());
		logger.info("Save operations completed");
		return true;
	}

	@Override
	public List<EmployeeDataModel> fetchAllUsersData() {
		
		List<EmployeeDataModel> empModel=new ArrayList<EmployeeDataModel>();
		List<EmployeeEntity> empEntity=null;
		empEntity = empRepo.findAll();
		for(EmployeeEntity entity:empEntity) {
			EmployeeDataModel empListModel=new EmployeeDataModel();
			BeanUtils.copyProperties(entity, empListModel);
			empModel.add(empListModel);
				}
		return empModel;

	}
/*	public ByteArrayInputStream load() {
	    List<EmployeeEntity> EmployeeTable = empRepo.findAll();
	    ByteArrayInputStream in = EmployeeDataExcel.empDataToExcel(EmployeeTable);
	    return in;
	  }
*/
	//@SuppressWarnings("unlikely-arg-type")
/*	@Override
	public String validateEmpID(Integer empID) {
	
		EmployeeEntity entity = new EmployeeEntity();
		entity = empRepo.findByEmpID(empID);
		
		System.out.println("empId from service class"+entity);
		return (entity == null) ? "Unique" : "Duplicate";

	}
*/
	/*@Override
	public Page<EmployeeEntity> findByPagination(int pageNo, int size) {
		 Pageable pageable = PageRequest.of(0,10);
		  return empRepo.findAll(pageable);
	}
*/
	@Override
	public String updateEmpDetails(EmployeeDataModel empModel) {
		//EmployeeDataModel empModel = new EmployeeDataModel();
		EmployeeEntity entity=new EmployeeEntity();
		BeanUtils.copyProperties(empModel, entity);
		logger.info(empModel.getFname());
		logger.info(empModel.getMname());
		logger.info(empModel.getLname());
		logger.info(empModel.getDepartment());
		logger.info(empModel.getSkills());
		logger.info(String.valueOf(empModel.getAge()));
		logger.info(String.valueOf(empModel.getEmpID()));
		
					
		//EmployeeEntity entity=new EmployeeEntity();
	/*	entity.setEmpID(empModel.getEmpID());
		entity.setFname(empModel.getFname());
		entity.setMname(empModel.getMname());
		entity.setLname(empModel.getLname());
		entity.setAge(empModel.getAge());
		entity.setDepartment(empModel.getDepartment());
		entity.setSkills(empModel.getSkills());
		entity.setDoj(empModel.getDoj());
	*/
		 empRepo.save(entity);
		 
		 return null;
		 
	}

	@Override
	public void deleteEmployeeByEmpID(Integer empID) {
		//EmployeeEntity entity=new EmployeeEntity();
		//1000004
	//	boolean exist = empRepo.existsById(empID);
		//boolean isPresent = true;
		//isPresent = empRepo.existsById(empID);
	empRepo.deleteByEmpID(empID);;
	
	
	}


	@Override
	public EmployeeDataModel findByEmpID(Integer empID) {
		EmployeeEntity entity=empRepo.findByEmpID(empID);
		EmployeeDataModel model=new EmployeeDataModel();
		
		model.setFname(entity.getFname());
		logger.info(entity.getFname());
		
		model.setMname(entity.getMname());
		logger.info(entity.getMname());
		
		model.setLname(entity.getLname());
		logger.info(entity.getLname());
		
		model.setAge(entity.getAge());
		logger.info(String.valueOf(entity.getAge()));
		
		model.setDepartment(entity.getDepartment());
		logger.info(entity.getDepartment());
		
		model.setEmpID(entity.getEmpID());
	
		model.setSkills(entity.getSkills());
		logger.info(entity.getSkills());
		
		model.setDoj(entity.getDoj());
		logger.info(String.valueOf(entity.getDoj()));
	
		return model;
	}

	

/*	@Override
	public Page<EmployeeEntity> findByPagination(int pageNo, int size) {
		// TODO Auto-generated method stub
		return null;
	}

/*	@Override
	public void updateInvoice(EmployeeDataModel empModel) {
		EmployeeEntity entity = new EmployeeEntity();
		BeanUtils.copyProperties(empModel, entity);
		System.out.println("service class::"+empModel.getSkills());
		empRepo.save(entity);
		
	}*/

	@Override
	public EmployeeEntity getEmpByEmpID(Integer empID) {
		EmployeeDataModel model=new EmployeeDataModel();
		Optional<EmployeeEntity> optional = empRepo.findById(empID);
		EmployeeEntity employeeEntity = null ;
		BeanUtils.copyProperties(model, employeeEntity);
		if(optional.isPresent()) {
			employeeEntity = optional.get();
		}else {
			throw new CustomException("Emplpoyee Not found for Id::"+empID);
		}
		return employeeEntity;
	}

/*	@Override
	public int updateByEmpID(Integer empID) {
		
		return empRepo.updateByEmpID(empID);
	}
*/
/*	@Override
	public String updateEmpDetails(EmployeeDataModel empModel, Integer empID) {
		Optional<EmployeeEntity> eModel = empRepo.findById(empID);
		
		
		
		return null;
	}

	*/


	

	
}
