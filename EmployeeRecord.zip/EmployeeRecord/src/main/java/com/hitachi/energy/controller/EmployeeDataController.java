package com.hitachi.energy.controller;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.hitachi.energy.entity.EmployeeEntity;
import com.hitachi.energy.helper.EmployeeDataInPdfFormat;
import com.hitachi.energy.model.EmployeeDataModel;
import com.hitachi.energy.service.EmployeeDataService;
import com.hitachi.energy.service.ExcelService;
import com.hitachi.energy.service.PdfService;


@Controller
public class EmployeeDataController {
	@Autowired
	private EmployeeDataService empService;

	@Autowired
	private PdfService pdfService;

	@Autowired
	ExcelService fileService;

	private static final Logger logger = LoggerFactory.getLogger(EmployeeDataController.class);

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String loadHomePage(Model model) {
		EmployeeDataModel empModel = new EmployeeDataModel();
		model.addAttribute("empModel", empModel);
		departmentList(model);
		logger.info("Inside controller class:: loading the homePage");
		return "home";

	}

	// we can use post redirect get pattern for double posting problem
	// @ExceptionHandler(value = EmployeeExceptions.class)
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String registerUser( @ModelAttribute(name = "empModel") EmployeeDataModel empModel, Model model,
			HttpServletRequest req, RedirectAttributes attribute) {
		      departmentList(model);
				empService.saveUser(empModel);
		logger.info("Inside controller class:: register the user");
		return "home";

	}

	public void departmentList(Model model) {

		List<String> deptList = new ArrayList<String>();

		deptList.add("PGHV");
		deptList.add("AIS");
		deptList.add("GIS");
		deptList.add("PGGI");
		model.addAttribute("deptList", deptList);

	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String listOfRecords(Model model,@ModelAttribute(name = "empModel") EmployeeDataModel empModel) {
		List<EmployeeDataModel> showEmpModel = new ArrayList<EmployeeDataModel>();
		showEmpModel = empService.fetchAllUsersData();
		// listofEmployee = empService.findByPagination(0, 10);
		model.addAttribute("showEmpModel", showEmpModel);
		logger.info("Inside controller class:: fetching all user's data");
		return "list";

	}

/*	@RequestMapping(value = "/validateID", method = RequestMethod.GET)
	public @ResponseBody String checkEmpID(HttpServletRequest req, Model model) {
		Integer empID = Integer.parseInt(req.getParameter("empID"));
		return empService.validateEmpID(empID);
	}
*/	

	@GetMapping("/updateEmployee")
	public String getEditPage(HttpServletRequest req, Model model) {
		Integer empID = Integer.parseInt(req.getParameter("empID"));
		
		EmployeeDataModel empModel = empService.findByEmpID(empID);
		departmentList(model);
		model.addAttribute("empModel", empModel);
		return "edit";
	}
	

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String updateEmpDetails(@ModelAttribute(name = "empModel") EmployeeDataModel empModel,
			HttpServletRequest req,  Integer empID) {
		
	 empService.updateEmpDetails(empModel);
		
		logger.info("Inside controller class:: updating employee details");
		
		return "redirect:/list";
	}

	@RequestMapping(value = "/deleteEmployee", method = RequestMethod.GET)
	public String delete(HttpServletRequest req, Model model, RedirectAttributes attributes) {

		Integer empID = Integer.parseInt(req.getParameter("empID"));
		empService.deleteEmployeeByEmpID(empID);
		logger.info("Inside controller class:: deleting the employee and redirecting tpo list page");
		return "redirect:/list";
	}

	@RequestMapping(value = "/download", method = RequestMethod.GET)
	public ResponseEntity<Resource> getFile() {
		String filename = "employeeSheet.xlsx";
		InputStreamResource file = new InputStreamResource(fileService.load());
		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
				.contentType(MediaType.parseMediaType("application/vnd.ms-excel")).body(file);
	}

	@RequestMapping(value = "/pdfreport", method = RequestMethod.GET, produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> empDataReport() {

		List<EmployeeEntity> empData = (List<EmployeeEntity>) pdfService.listAll();

		ByteArrayInputStream bis = EmployeeDataInPdfFormat.employeeDataReport(empData);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline; filename=citiesreport.pdf");

		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bis));
	}

	
	
	
	
}
