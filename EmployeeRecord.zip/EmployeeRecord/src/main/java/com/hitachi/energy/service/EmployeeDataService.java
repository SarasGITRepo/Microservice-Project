package com.hitachi.energy.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.hitachi.energy.entity.EmployeeEntity;
import com.hitachi.energy.model.EmployeeDataModel;

public interface EmployeeDataService {
	
	public boolean saveUser(EmployeeDataModel emodel);
	
	public List<EmployeeDataModel> fetchAllUsersData();
	
	//public String validateEmpID(Integer empID);
	
	//Page<EmployeeEntity> findByPagination(int pageNo, int size);
	
	public String updateEmpDetails(EmployeeDataModel empModel);
	
//	public int updateByEmpID(Integer empID);
	public void deleteEmployeeByEmpID(Integer empID);
	 
	public EmployeeDataModel findByEmpID(Integer empID);
	// public EmployeeDataModel findByEmpID(Long empID);
	// public void updateInvoice(EmployeeDataModel empModel);
	
	EmployeeEntity getEmpByEmpID(Integer empID);

}
