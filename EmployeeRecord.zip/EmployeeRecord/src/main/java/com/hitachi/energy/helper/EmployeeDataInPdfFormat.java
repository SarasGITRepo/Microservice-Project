package com.hitachi.energy.helper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import com.hitachi.energy.entity.EmployeeEntity;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class EmployeeDataInPdfFormat {
	
    
	 public static ByteArrayInputStream employeeDataReport(List<EmployeeEntity> entity) {

	        Document document = new Document();
	        ByteArrayOutputStream out = new ByteArrayOutputStream();

	        try {

	        	PdfPTable table = new PdfPTable(8);
	    		table.setSpacingBefore(25);
	    		table.setSpacingAfter(25);

	    		//PdfPCell c1 = new PdfPCell(new Phrase("SLNO"));
	    		//table.addCell(c1);

	    		PdfPCell c1 = new PdfPCell(new Phrase("Fname"));
	    		table.addCell(c1);
	    		
	    		PdfPCell c2 = new PdfPCell(new Phrase("Mname"));
	    		table.addCell(c2);
	    		PdfPCell c3 = new PdfPCell(new Phrase("Lname"));
	    		table.addCell(c3);
	    		
	    		PdfPCell c4 = new PdfPCell(new Phrase("Age"));
	    		table.addCell(c4);

	    		PdfPCell c5 = new PdfPCell(new Phrase("Employee ID"));
	    		table.addCell(c5);

	    		PdfPCell c6 = new PdfPCell(new Phrase("Department"));
	    		table.addCell(c6);

	    		PdfPCell c7= new PdfPCell(new Phrase("Skills"));
	    		table.addCell(c7);
	    		
	    		PdfPCell c8 = new PdfPCell(new Phrase("DOJ"));
	    		table.addCell(c8);

	            for (EmployeeEntity entities : entity) {

	               PdfPCell cell;

	               cell = new PdfPCell();
	                
	               // table.addCell(String.valueOf(entities.getId()));
	            	
	                table.addCell(String.valueOf(entities.getFname()));
	                table.addCell(String.valueOf(entities.getMname()));
	                table.addCell(String.valueOf(entities.getLname()));
	                table.addCell(String.valueOf(entities.getAge()));
	                table.addCell(String.valueOf(entities.getEmpID()));
	                table.addCell(String.valueOf(entities.getDepartment()));
	                table.addCell(String.valueOf(entities.getSkills()));
	                table.addCell(String.valueOf(entities.getDoj()));
	                
	               
	              
	                
	            }

	            PdfWriter.getInstance(document, out);
	            document.open();
	            document.add(table);

	            document.close();

	        } catch (DocumentException ex) {

	            ex.getMessage();
	        }

	        return new ByteArrayInputStream(out.toByteArray());

    }
}
