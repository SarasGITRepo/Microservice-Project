package com.hitachi.energy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeRecordApplicationTests {

	@Test
	void contextLoads() {
	}

}
