package com.demo.hi.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "HelloService")
public interface HelloClient {
	
	@GetMapping(value= "/hello/{name}")
	public String callHelloService(@PathVariable("name") String name);

}
