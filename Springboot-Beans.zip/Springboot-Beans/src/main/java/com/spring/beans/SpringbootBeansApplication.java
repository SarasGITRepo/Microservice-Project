package com.spring.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import com.spring.beans.singleton.SpringScopes;

@SpringBootApplication

public class SpringbootBeansApplication implements CommandLineRunner{
	
	@Autowired
	ApplicationContext ctx;
	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringbootBeansApplication.class, args);
		
		
	}

	public void run(String... arg0) throws Exception{
		
		SpringScopes	 single = ctx.getBean(SpringScopes.class);
		System.out.println("scope::" +single);
		SpringScopes single2 = ctx.getBean(SpringScopes.class);
		single2.setName("smita");
		System.out.println("scope::" +single2);
		
		
	}
	
}
