package com.spring.beans.singleton;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;


@Component
//by default scope = singleton
//@Scope("prototype")

public class SpringScopes {
	
	private String name;
	
	public SpringScopes() {
		System.out.println("******one object created**********");
	}
	
	
	


	public String getName() {
		return name;
	}

	@Value("Saras")
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "SingletonScope [name=" + name + "]";
	}


	

}
